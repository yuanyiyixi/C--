#define CRTC2

#include "mga_vid.c"
